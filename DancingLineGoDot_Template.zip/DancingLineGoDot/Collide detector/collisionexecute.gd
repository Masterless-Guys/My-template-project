extends Area3D

@export_enum("Velocityjump", "changedirection", "Win?", "withoutclick", "Camera change", "Direction UTURN", "Disable") var whenDetect:int
@export_group("When Scale collider")
@export var scalecollide:Vector3 = Vector3(1.0, 1.0, 1.0)
@export_group("Make a jump velocity")
@export var jump_velocity:float
@export_group("direction turn")
@export_enum("When cube turned", "When cube stretch back") var direcstret:int
@export var directionchange:int
@export_group("Make a without click?")
#Toggle without click while this whenDetect call script
@export_enum("Enable", "Disable") var Toggle_without_click:int = 1
@export_group("VectorCamera")
#This is Called global group to tell you
@export_enum("Both", "Rotate", "Position", "Disable") var SelectorChange:int = 2
@export var VectorChecker:Vector3
@export var RotateChecker:Vector3
@export_group("DirectionFront marker")
@export_enum("Foward", "Backward", "Leftward", "Rightward") var Directioninfront:int = 0
@export_group("")


func _ready() -> void:
	$CollisionShape3D/UFF.hide()
	$CollisionShape3D/UFF.scale = scalecollide
	

func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("globalcharacter"):
		if whenDetect == 0:
			#Jump velocity
			body.Jumpercause(jump_velocity)
			get_tree().call_group("globalcharacter", "Jumpercause", jump_velocity)
			
		elif whenDetect == 1:
			#Direction
			if direcstret == 0:
				#Have Direction angle
				body.Direction_focusvhasin(directionchange)
				
			elif direcstret == 1:
				#Have Stretch back
				body.Direction_focusxhasin(directionchange)
				
			else:
				#Override didn't active
				direcstret = 0
				
			
		elif whenDetect == 2:
			#Win cube
			body.Spawntailwin()
			
		elif whenDetect == 3:
			if Toggle_without_click == 0:
				body.Cube_without_click(true)
				
			elif Toggle_without_click == 1:
				body.Cube_without_click(false)
				
			
		elif whenDetect == 4:
			if SelectorChange != 3:
				
				
				if SelectorChange == 0:
					pass
				elif SelectorChange == 1:
					pass
				elif SelectorChange == 2:
					get_tree().call_group("Camera FGHY", "Camera_Change_Position", Vector3(VectorChecker))
					
					
				
			
			
		elif whenDetect == 5:
			body.Changedirection(Directioninfront)
			
			
		
		
	
	

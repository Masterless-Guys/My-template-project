extends CharacterBody3D

#const musicsprite = preload("res://Bliztered.tscn")
const musicsprite = preload("uid://cf48m7uv7qs04")
#const Tail = preload("res://Tscn/Object/Player cube tail/cube_tail.tscn")
const Tail = preload("uid://dvnh6rqyc3f5y")
const cubephysicalsheme = preload("uid://o8qfqe68wqxp")

var position_start:Vector3

@export var colorCubeis:Color = Color(0.7, 0.7, 0.7, 1.0)



@export var Speeddocube:float = 10.0
@export var fallsgravity:float = 7.0
var startfod := false
# Diretion mass was (0 Right top, 1 Left top, 2 Left down, 3 Right down)
@export var directionmass:int = 0
var died_cube := false
@export_group("Referce fall down")
@export_enum("On", "Off") var when_falldown:int = 0
@export_enum("Enable", "Disable") var withoutclick_falldown:int = 0
@export_group("series advanced")
@export var UTurnAdvanced:bool = false
@export_group("")
@export_enum("Normal", "Headphone", "HeadStick") var SkinScotte:int = 1



var Hitted_ground:bool = false

var multitouchsupport := false

@export_enum("Foward", "Backward", "Leftward", "Rightward") var directionchoice: int

@export_group("CheckpointChecker")
@export var checkpoint_crown_I_pos:Marker3D
@export var checkpoint_crown_II_pos:Marker3D
@export var checkpoint_crown_III_pos:Marker3D

@export var checkpoint_crown_I_Rotate:int
@export var checkpoint_crown_II_Rotate:int
@export var checkpoint_crown_III_Rotate:int

@export var checkpoint_crown_I_Sound:float
@export var checkpoint_crown_II_Sound:float
@export var checkpoint_crown_III_Sound:float

@export var Player_need_die = false

var fallsgravityreverse:float = fallsgravity * -1

var failcube:bool = false

var sinfovector:Vector3 = Vector3.ZERO
#var sindavector:Vector3

var capturehitground:float = 0.0

var cube_is_win:bool = false
var cube_without_click:bool = false

@onready var particleEngine = $GPUParticles3D

func reset_game(continuegame:bool):
	get_tree().call_group("sceneBlopperLol", "Free_removalself")
	get_tree().call_group("debriscube", "eraseme")
	if continuegame:
		pass
		
	else:
		global_position = position_start
		
	

func _ready() -> void:
	position_start = global_position
	Continue_game()
	#Headphone or Normal
	if SkinScotte == 0:
		$Cubemaster/Stick.hide()
		$Cubemaster/Headphone.hide()
		
	elif SkinScotte == 1:
		$Cubemaster/Stick.hide()
		$Cubemaster/Headphone.show()
		
	elif SkinScotte == 2:
		$Cubemaster/Stick.show()
		$Cubemaster/Headphone.hide()
		
		
	
	#Side
	
	
	#$Cubemaster.global_rotation_degrees.y = 0
	Jumpercause(5)
	cube_is_win = false
	failcube = false
	
	#print(directionchoice)
	#push_error("haha")
	#push_warning("haha")
	#print_rich("[color=yellow]<text here>")
	#await get_tree().create_timer(5).timeout
	#colorCubeis = Color(0.2,0.2,0.2,1.0)
	
	#pass
	

func Continue_game():
	if Sgla.game_current == 0:
		if Sgla.Checkpoint_crown == 1:
			if checkpoint_crown_I_pos != null:
				global_position = checkpoint_crown_I_pos.global_position
				rotatline(checkpoint_crown_I_Rotate)
				
			else:
				print("Checkpoint crown 1 but where Marker3d")
				
			
		if Sgla.Checkpoint_crown == 2:
			if checkpoint_crown_II_pos != null:
				global_position = checkpoint_crown_II_pos.global_position
				
				
			else:
				print("Checkpoint crown 2 but where Marker3d")
				
				
			
			
		if Sgla.Checkpoint_crown == 3:
			if checkpoint_crown_III_pos != null:
				global_position = checkpoint_crown_III_pos.global_position
				
				
			else:
				"Checkpoint crown 3 but where Marker3d"
				
				
				
			
			
			
		
	


func Cube_Crashed():
	if Player_need_die:
		var cubephysic = cubephysicalsheme.instantiate()
		get_tree().current_scene.add_child(cubephysic)
		cubephysic.global_position = global_position
		cubephysic.colormax(colorCubeis)
		
		if not failcube:
			failcube = true
		





func rotatline(Direction:int):
	
	if directionchoice == 0:
		#foward
		if Direction == 0:
			directionmass = 1
		elif Direction == 1:
			directionmass = 0
		elif Direction == 2:
			directionmass = 0
		elif Direction == 3:
			directionmass = 1
		
	elif directionchoice == 1:
		#reverse
		if Direction == 0:
			directionmass = 2
		elif Direction == 1:
			directionmass = 3
		elif Direction == 2:
			directionmass = 3
		elif Direction == 3:
			directionmass = 2
		
	elif directionchoice == 2:
		#left
		if Direction == 0:
			directionmass = 2
		elif Direction == 1:
			directionmass = 2
		elif Direction == 2:
			directionmass = 1
		elif Direction == 3:
			directionmass = 1
		
	elif directionchoice == 3:
		#right
		if Direction == 0:
			directionmass = 3
		elif Direction == 1:
			directionmass = 3
		elif Direction == 2:
			directionmass = 0
		elif Direction == 3:
			directionmass = 0
	
	if Direction == 0:
		$Cubemaster.global_rotation_degrees.y = 0
		
		
	elif Direction == 1:
		$Cubemaster.global_rotation_degrees.y = 90
		
		
	elif Direction == 2:
		$Cubemaster.global_rotation_degrees.y = 180
		
		
	elif Direction == 3:
		$Cubemaster.global_rotation_degrees.y = 270
		
		
	
	



func _input(event: InputEvent) -> void:
	
	if Input.is_action_just_released("Pause"):
		if not get_tree().paused:
			get_tree().paused = true
			
		elif get_tree().paused:
			get_tree().paused = false
			
		
	
	
	#broke
	if event is InputEventScreenTouch:
		if event.pressed and not Input.is_action_just_pressed("Pause"):
			if event.index == 0 or multitouchsupport == true:
				
				for Ound in get_tree().get_nodes_in_group("AudioUI Group"):
					if Ound is AudioStreamPlayer and not Ound.playing:
						if is_on_floor():
							#play or seek
							##that matter a counting .play(5.0) play set time, .seek(5.0) that incoming set time
							if Sgla.game_current == 0:
								if Sgla.Checkpoint_crown == 0:
									Ound.play()
									
								elif Sgla.Checkpoint_crown == 1 and checkpoint_crown_I_pos != null:
									Ound.play(checkpoint_crown_I_Sound)
									
								
							
							
							
							
						
					
					
				
				#Input.action_press("Bronachopressed")
				if not startfod:
					if is_on_floor() and when_falldown == 0:
						startfod = true
						get_tree().call_group("CtrlUX", "openbutton")
						
					if when_falldown == 1 and withoutclick_falldown == 1:
						startfod = true
						get_tree().call_group("CtrlUX", "openbutton")
						
					
					
				if startfod and not died_cube:
					if ((is_on_floor() and when_falldown == 0) or (when_falldown == 0 and withoutclick_falldown == 1)) and not cube_without_click:
						DirectionPointac()
						callposecam()
					if when_falldown == 1 and not cube_without_click:
						DirectionPointac()
						callposecam()
					
					
				if (is_on_floor() and when_falldown == 0 or when_falldown == 1 and withoutclick_falldown == 1) and (not cube_is_win and not cube_without_click):
					callvoid()
					
				#DueDua()
				
				#Spawntail()
				#Spawntail2()
				
				#Tap_to_Rotate()
				
			#DueDua()
			
			#Spawntail()
			#Spawntail2()
			
			#Tap_to_Rotate()
			
			
			
			
		
		
		
	
	
	
	
	#if Input.is_action_just_pressed("Bronachopressed"):
		#Tap_to_Rotate()
		
		

func callposecam():
	if UTurnAdvanced:
		if directionchoice == 0:
			get_tree().call_group("Camera FGHY", "Camera_Change_Position", Vector3(3,5,3))
			
		elif directionchoice == 1:
			get_tree().call_group("Camera FGHY", "Camera_Change_Position", Vector3(5,5,5))
			
		elif directionchoice == 2:
			get_tree().call_group("Camera FGHY", "Camera_Change_Position", Vector3(2,5,6.5))
			
		elif directionchoice == 3:
			get_tree().call_group("Camera FGHY", "Camera_Change_Position", Vector3(6.5,5,2))
			
			
	

func callvoid():
	DueDua(true)
	
	Spawntail2()
	


func DueDua(dealcall:bool):
	get_tree().call_group("sceneBlopper", "treatline", dealcall)
	


func Jumpercause(Variantfloat: float):
	
	if when_falldown == 0 and is_on_floor() or not is_on_floor():
		velocity.y = Variantfloat
		
		
	#velocity.y = Variantfloat
	

var counting_wait:int = 20
var default_counting_wait:int = 20

#way here
func _process(_delta: float) -> void:
	
	#for soundmxc in get_tree().get_nodes_in_group("AudioUI Group"):
		#if soundmxc is AudioStreamPlayer:
			#print(snappedf(soundmxc.get_playback_position(), 0.01))
			
			
		
	
	
	##together
	$Cubemaster.get_active_material(0).albedo_color = colorCubeis
	get_tree().call_group("sceneBlopper", "changingcolortheline" , colorCubeis)
	#loss#
	
	if startfod:
		#Spawntail2()
		#print(is_on_floor())
		if SkinScotte == 1:
			if counting_wait == 0:
				var Spritemusic = musicsprite.instantiate()
				get_tree().current_scene.add_child(Spritemusic)
				Spritemusic.global_position = global_position
				counting_wait = default_counting_wait
				
			elif counting_wait >= 0:
				counting_wait -= 1
				
			elif counting_wait <= 0:
				counting_wait += 1
				
			else:
				counting_wait = default_counting_wait
				
			
			
		
		
	
	


func _physics_process(delta: float) -> void:
	#var sinfovector:Vector3 = Vector3.ZERO
	#var sindavector:Vector3
	
	if not is_on_floor() and when_falldown == 0:
		velocity.y += fallsgravityreverse * delta
		Hitted_ground = false
		capturehitground = velocity.y
		
	
	#make a hitted ground
	
	if is_on_floor() and when_falldown == 0:
		if startfod:
			if not Hitted_ground and startfod:
				#ShaderBow()
				
				if not cube_is_win:
					Spawntail2()
					
				else:
					SpawntailwinE()
					
				
			
		#elif not Hitted_ground:
			#ShaderBow()
			
		
		
		Hitted_ground = true
		
	
	if startfod and not died_cube:
		
		
		
		if directionmass == 0 and not cube_is_win:
			sinfovector.z = Speeddocube * -35.0
			sinfovector.x = 0.0
			
			
			
		if directionmass == 1 and not cube_is_win:
			sinfovector.z = 0.0
			sinfovector.x = Speeddocube * -35.0
			
			
		if directionmass == 2 and not cube_is_win:
			sinfovector.z = Speeddocube * 35.0
			sinfovector.x = 0.0
			
			
		if directionmass == 3 and not cube_is_win:
			sinfovector.z = 0.0
			sinfovector.x = Speeddocube * 35.0
			
			
		if cube_is_win:
			if directionchoice == 0:
				sinfovector.z = Speeddocube * -20.0
				sinfovector.x = Speeddocube * -20.0
				
			if directionchoice == 1:
				sinfovector.z = Speeddocube * 20.0
				sinfovector.x = Speeddocube * 20.0
				
			
		
		
		velocity.z = sinfovector.z * delta
		velocity.x = sinfovector.x * delta
		
		
		
		
		
	if not (Player_need_die and failcube):
		move_and_slide()
		
	
	if is_on_floor() and not Hitted_ground and capturehitground <= -3:
		ShaderBow()
		
	
	
	#if startfod:
		#if directionmass:
			#$MeshInstance3D.rotation_degrees.y = -2
			
			#pass
			
		
		#if not directionmass:
			#$MeshInstance3D.rotation_degrees.y = 88
			
			#pass
			
		
		
		
	
	
	
	
	
	if not sinfovector.is_zero_approx() and not(Player_need_die and failcube):
		$Cubemaster.global_basis = Basis.looking_at(sinfovector)
		$CollisionShape3D.global_basis = Basis.looking_at(sinfovector)
		
		
	
	
	if not is_on_floor() and when_falldown == 0:
		#landed?
		get_tree().call_group("sceneBlopper", "treatline", false)
		
		
	
	
	
	


func DirectionPointac():
	if directionchoice == 0:
		if directionmass == 0:
			directionmass = 1
		elif directionmass == 1:
			directionmass = 0
		elif directionmass == 2:
			directionmass = 1
		elif directionmass == 3:
			directionmass = 0
	elif directionchoice == 1:
		if directionmass == 2:
			directionmass = 3
		elif directionmass == 3:
			directionmass = 2
		elif directionmass == 1:
			directionmass = 2
		elif directionmass == 0:
			directionmass = 3
	elif directionchoice == 2:
		if directionmass == 2:
			directionmass = 1
		elif directionmass == 1:
			directionmass = 2
		elif directionmass == 3:
			directionmass = 2
		elif directionmass == 0:
			directionmass = 1
	elif directionchoice == 3:
		if directionmass == 0:
			directionmass = 3
		elif directionmass == 3:
			directionmass = 0
		elif directionmass == 1:
			directionmass = 0
		elif directionmass == 2:
			directionmass = 3


func Spawntail():
	if Player_need_die and failcube:
		return
	
	
	var jeus = Tail.instantiate()
	jeus.global_transform = global_transform
	get_tree().current_scene.add_child(jeus)
	
	


func Spawntail2():
	if Player_need_die and failcube:
		return
		
	
	var jeus = Tail.instantiate()
	jeus.global_transform = global_transform
	get_tree().current_scene.add_child(jeus)
	
	
	

func Spawntailwin():
	get_tree().call_group("sceneBlopper", "treatline")
	if directionmass == 0 and directionchoice == 0:
		global_position.x += 0.05
		global_position.z += -0.07
	if directionmass == 1 and directionchoice == 0:
		global_position.x += -0.07
		global_position.z += 0.05
		
	
	if directionmass == 2 and directionchoice == 1:
		global_position.x += -0.07
		global_position.z += 0.15
		
	if directionmass == 3 and directionchoice == 1:
		global_position.x += 0.15
		global_position.z += -0.07
		
	
	if not cube_is_win:
		var jeus = Tail.instantiate()
		jeus.global_transform = global_transform
		get_tree().current_scene.add_child(jeus)
		jeus.directionstraighted(directionchoice)
		
	
	cube_is_win = true
	

func SpawntailwinE():
	if Player_need_die and failcube:
		return
	
	var jeus = Tail.instantiate()
	jeus.global_transform = global_transform
	get_tree().current_scene.add_child(jeus)
	jeus.directionstraighted(directionchoice)
	

func Tap_to_Rotate():
	print("Son")


func Changedirection(CtD: int):
	directionchoice = CtD
	

#func Direction_focus(Std: int, Hasin: bool):
	#directionmass = Std
	#if Hasin:
		#get_tree().call_group("sceneBlopperLol", "treatline")
		#Spawntail2()
		
	
	


func Direction_focusxhasin(Std: int):
	directionmass = Std
	

func Direction_focusvhasin(Std: int):
	directionmass = Std
	get_tree().call_group("sceneBlopperLol", "treatline")
	Spawntail2()
	

func Cube_without_click(Udts: bool):
	cube_without_click = Udts
	


func ShaderBow():
	particleEngine.restart()
	particleEngine.emitting = true
	
	


func _on_area_3d_body_entered(body: Node3D) -> void:
	if not body == $Cubemaster or not body == $CollisionShape3D:
		if Player_need_die:
			Cube_Crashed()
			
			
		
	

extends Camera3D

@export_group("Vector referced")
@export var offsetvector:Vector3
@export_group("Vector rotate")
@export var offsetrotate:Vector3
@export_group("")


func _ready() -> void:
	global_rotation_degrees = offsetrotate
	

func _process(delta: float) -> void:
	global_position -= (((global_position - offsetvector) - $"../Cube line".global_position) * 2.8332 ) * delta
	

func Camera_Change_Position(Vectorsystem:Vector3):
	offsetvector = Vectorsystem
	

func Camera_Reset_Position():
	offsetvector = Vector3(3, 5, 3)
	
	

func Camera_Change_Rotation(Vectorsystem:Vector3):
	offsetrotate = Vectorsystem
	
	

func Camera_Reset_Rotation():
	offsetrotate = Vector3(-30, 45, 0)
	

func Camera_Transform(VectorSystemA:Vector3, VectorSystemB:Vector3):
	offsetvector = VectorSystemA
	offsetrotate = VectorSystemB
	
	

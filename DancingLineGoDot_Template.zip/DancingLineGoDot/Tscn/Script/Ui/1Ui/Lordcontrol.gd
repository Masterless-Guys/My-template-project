extends Control

var pausedin = false


func _ready() -> void:
	get_tree().set_auto_accept_quit(false)
	await get_tree().create_timer(5).timeout
	



func openbutton():
	
	$"touch pause".show()
	

func _input(_event: InputEvent) -> void:
	if Input.is_action_just_released("Pause"):
		$"touch pause".hide()
		
	

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			resume_touch()
			
		
		
	
	


func _notification(what: int) -> void:
	match what:
		MainLoop.NOTIFICATION_APPLICATION_PAUSED:
			Input.action_press("Pause")
			
	
	
	
	

func resume_touch() -> void:
	
	$"touch pause".show()
	
	#if get_tree().paused and pausedin:
	get_tree().paused = false
	pausedin = false
	
	


#func _process(_delta: float) -> void:	
	
	#if Input.is_action_just_released("Pause"):
		#if get_tree().paused and pausedin:
			#get_tree().paused = false
			#pausedin = false
			
		#elif not (get_tree().paused and pausedin):
			#get_tree().paused = true
			#pausedin = true
			
		
		
	

extends MeshInstance3D

@export var cubepath: NodePath
@export_enum("Normal", "stretch", "Advanced") var TypeMode:int

var Vector_ready:Vector3
#var playerposition:Vector3 = get_tree().get_node_in_group("globalcharacter").global_position
var readyfa := false
var readyca := false
var playervector:Vector3
var vector_divine:Vector3 = (Vector_ready - playervector) / 2
var readyHga := false
var distanceleader:float

var direction_redis:int = 0

var dnew:int = 0


func Free_removalself():
	queue_free()


func _ready() -> void:
	
	Vector_ready = position
	scale = Vector3(1 , 1, 1)
	readyfa = true
	rotation.y = 0
	rotation_degrees.y = 0
	
	pass
	

func _unhandled_input(_event: InputEvent) -> void:
	if Input.is_action_just_pressed("Bronachopressed"):
		#treatline()
		pass
		

#LockStretch giving the bese decided
var SimplyLockStretch:bool = true
#If You Changed LockStretchFrom Can Cause Undone Mess
var LockStretchFrom:int = 0

func _process(_delta: float) -> void:
	var playerarea = get_tree().get_nodes_in_group("globalcharacter")
	for bodydirect in playerarea:
		if "global_position" in bodydirect:
			playervector = bodydirect.global_position
			#print("body located ", bodydirect.global_position, "called ", playervector)
			
	
	var playerdistance = get_tree().get_nodes_in_group("globalcharacter")
	for bodypositiondistance in playerdistance:
		if "global_position" in bodypositiondistance:
			var distancefound = global_position.distance_to(bodypositiondistance.global_position)
			
			distanceleader = distancefound
			
			
	
	#var playerposition = get_tree().get_node_in_group("globalcharacter")
	
	
	if readyfa and not readyca:
		#LockStretch
		if SimplyLockStretch:
			if Vector_ready.x != playervector.x and not(Vector_ready.z != playervector.z):
				LockStretchFrom = 1
				
			if Vector_ready.z != playervector.z and not(Vector_ready.x != playervector.x):
				LockStretchFrom = 2
				
			
		
		#Typemode sided
		if TypeMode == 0:
			global_position.z = (Vector_ready.z + playervector.z) / 2
			global_position.x = (Vector_ready.x + playervector.x) / 2
		elif TypeMode == 1:
			if (Vector_ready.z - playervector.z) != 0 and (Vector_ready.x - playervector.x) == 0:
				direction_redis = 1
				
			elif (Vector_ready.x - playervector.x) != 0 and (Vector_ready.z - playervector.z) == 0:
				direction_redis = 2
				
			
			#if (Vector_ready.z - playervector.z) != 0:
				#global_position.z = (Vector_ready.z + playervector.z) / 2
				
			#elif (Vector_ready.x - playervector.x) != 0:
				#global_position.x = (Vector_ready.x + playervector.x) / 2
				
			if direction_redis == 1:
				global_position.z = (Vector_ready.z + playervector.z) / 2
				
			elif direction_redis == 2:
				global_position.x = (Vector_ready.x + playervector.x) / 2
				
			
			
			
		elif TypeMode == 2:
			if (Vector_ready.z != playervector.z and Vector_ready.x == playervector.x) and (dnew == 0 or dnew == 1):
				#print("Z pointing")
				dnew = 1
			elif (Vector_ready.x != playervector.x and Vector_ready.z == playervector.z) and (dnew == 0 or dnew == 2):
				#print("X pointing")
				dnew = 2
				
			else: #print("tie")
				dnew = 0
				
			
			if Vector_ready.z != playervector.z and Vector_ready.z > playervector.z:
				global_position.z = ((Vector_ready.z + playervector.z) / 2) + 0.25
				
			elif Vector_ready.z != playervector.z and Vector_ready.z < playervector.z:
				global_position.z = ((Vector_ready.z + playervector.z) / 2) - 0.25
				
			
			if Vector_ready.x != playervector.x and Vector_ready.x > playervector.x:
				global_position.x = ((Vector_ready.x + playervector.x) / 2) + 0.25
				
			elif Vector_ready.x != playervector.x and Vector_ready.x < playervector.x:
				global_position.x = ((Vector_ready.x + playervector.x) / 2) - 0.25
				
				
			
		
		if not readyHga and TypeMode == 0:
			if Vector_ready.z - playervector.z > 0:
				scale.z = ((Vector_ready.z - playervector.z) * 2 ) + 1
				
				
			elif Vector_ready.z - playervector.z < 0:
				scale.z = ((Vector_ready.z - playervector.z) * 2 ) - 1
				
				
			elif Vector_ready.z - playervector.z == 0:
				scale.z = 1
				
			else:
				print("is not way")
				pass
				
			if Vector_ready.x - playervector.x > 0:
				scale.x = ((Vector_ready.x - playervector.x) * 2 ) + 1
				
			elif Vector_ready.x - playervector.x < 0:
				scale.x = ((Vector_ready.x - playervector.x) * 2 ) - 1
				
				
			elif Vector_ready.x - playervector.x == 0:
				scale.x = 1
			else:
				
				print("is not way")
				pass
				
			
			
			
		elif not readyHga and TypeMode == 1:
			if Vector_ready.z - playervector.z > 0 and not Vector_ready.x - playervector.x != 0 and dnew == 1:
				scale.z = ((Vector_ready.z - playervector.z) * 2 ) + 1
				
				
			elif Vector_ready.z - playervector.z < 0 and not Vector_ready.x - playervector.x != 0 and dnew == 1:
				scale.z = ((Vector_ready.z - playervector.z) * 2 ) - 1
				
				
			elif Vector_ready.z - playervector.z == 0 and dnew == 1:
				scale.z = 1
				
			else:
				print("is not way")
				
				
			if Vector_ready.x - playervector.x > 0 and not Vector_ready.z - playervector.z != 0 and dnew == 2:
				scale.x = ((Vector_ready.x - playervector.x) * 2 ) + 1
				
			elif Vector_ready.x - playervector.x < 0 and not Vector_ready.z - playervector.z != 0 and dnew == 2:
				scale.x = ((Vector_ready.x - playervector.x) * 2 ) - 1
				
				
			elif Vector_ready.x - playervector.x == 0 and dnew == 2:
				scale.x = 1
			else:
				
				print("is not way")
				
				
			
			
		elif not readyHga and TypeMode == 2:
			if Vector_ready.z - playervector.z != 0 and dnew == 1:
				scale.z = ((Vector_ready.z - playervector.z) * 2 )
				scale.x = ((Vector_ready.x - playervector.x) * 2 ) +1
				
			#elif Vector_ready.z - playervector.z < 0:
				#scale.z = ((Vector_ready.z - playervector.z) * 2 )
				#scale.x = ((Vector_ready.x - playervector.x) * 2 )
				
			elif Vector_ready.z - playervector.z == 0 and dnew == 1:
				scale.z = 1
				
				
			else:
				if (Vector_ready.z == playervector.z) and dnew == 0:
					print("is not way Z")
					return
				
				
				
			if Vector_ready.x - playervector.x != 0 and dnew == 2:
				scale.x = ((Vector_ready.x - playervector.x) * 2 )
				scale.z = ((Vector_ready.z - playervector.z) * 2 ) + 1
				
			#elif Vector_ready.x - playervector.x < 0:
				#scale.x = ((Vector_ready.x - playervector.x) * 2 )
				#scale.z = ((Vector_ready.z - playervector.z) * 2 )
				
			elif Vector_ready.x - playervector.x == 0 and dnew == 2:
				scale.x = 1
				
				
			
			else:
				if (Vector_ready.x == playervector.x) and dnew == 0:
					print("is not way X")
					return
				
				
				
			
			
			#scale.x = 1.0
			#scale.z = distanceleader * 4
			
			
			
		
		#scale = Vector3((Vector_ready.x - playervector.x), 1 ,(Vector_ready.z - playervector.z))  
		
		
	#print(scale)
	
	

#func _physics_process(_delta: float) -> void:
	
	#if readyfa and not readyca:
		#global_position.z = (Vector_ready.z + playervector.z) / 2
		#scale.z = (Vector_ready.z - playervector.z) * 2
		
		#global_position.x = (Vector_ready.x + playervector.x) / 2
		#scale.x = (Vector_ready.x - playervector.x) * 2
		
		
		
		

func directionstraighted(direct1z4: int):
	if direct1z4 == 0:
		global_rotation_degrees.y = 45
		
	if direct1z4 == 1:
		global_rotation_degrees.y = -135
		
	if direct1z4 == 2:
		global_rotation_degrees.y = 135
		
	if direct1z4 == 3:
		global_rotation_degrees.y = -45
		
	readyHga = true
	#print(direct1z4)
	

func changingcolortheline(Colorpass:Color):
	get_active_material(0).albedo_color = Colorpass
	

func treatline(decidedchoice:bool):
	#self.basis = Vector_ready - Cube.global_position
	#self.position = Vector_ready - Cube.global_position
	#if not readyfa:
		#readyfa = true
		
	if readyfa and not readyca:
		readyca = true
		if TypeMode == 2 and decidedchoice:
			#Pack Position
			global_position.z = (Vector_ready.z + playervector.z) / 2
			global_position.x = (Vector_ready.x + playervector.x) / 2
			#Pack Scale
			if Vector_ready.z - playervector.z > 0 and not Vector_ready.x - playervector.x != 0 and dnew == 1 :
				scale.z = ((Vector_ready.z - playervector.z) * 2 ) + 1
				
				
			elif Vector_ready.z - playervector.z < 0 and not Vector_ready.x - playervector.x != 0 and dnew == 1 :
				scale.z = ((Vector_ready.z - playervector.z) * 2 ) - 1
				
				
			elif Vector_ready.z - playervector.z == 0:
				scale.z = 1
				
			else:
				if dnew == 0 and not dnew == 2 and Vector_ready.z == playervector.z:
					print("is not way Z point")
					queue_free()
				
				
			if Vector_ready.x - playervector.x > 0 and not Vector_ready.z - playervector.z != 0 and dnew == 2 :
				scale.x = ((Vector_ready.x - playervector.x) * 2 ) + 1
				
			elif Vector_ready.x - playervector.x < 0 and not Vector_ready.z - playervector.z != 0 and dnew == 2 :
				scale.x = ((Vector_ready.x - playervector.x) * 2 ) - 1
				
				
			elif Vector_ready.x - playervector.x == 0:
				scale.x = 1
			else:
				if dnew == 0 and dnew == 2 and Vector_ready.x == playervector.x:
					print("is not way X point")
					queue_free()
					
				
				
			#endline
			
			
		
		
		
	
	##print("Daye")
	pass
	

extends CanvasLayer



func _ready():
	# Create an HTTP request node and connect its completion signal.
	$HTTPRequest.request_completed.connect(self._http_request_completed)
	

	# Perform the HTTP request. The URL below returns a PNG image as of writing.
	var error = $HTTPRequest.request("https://placehold.co/512.png")
	if error != OK:
		push_error("An error occurred in the HTTP request.")
		return

# Called when the HTTP request is completed.
func _http_request_completed(result, _response_code, _headers, body):
	if result != HTTPRequest.RESULT_SUCCESS:
		push_error("Image couldn't be downloaded. Try a different image.")
		return

	var image = Image.new()
	var error = image.load_png_from_buffer(body)
	if error != OK:
		push_error("Couldn't load the image.")
		return
	
	
	var textures = ImageTexture.create_from_image(image)
	
	$acc/TextureRect.texture = textures
	
	
	print(textures)
	
	
	# Display the image in a TextureRect node.
	#var texture_rect = TextureRect.new()
	#add_child(texture_rect)
	#texture_rect.texture = texture



func _on_web_builda_pressed() -> void:
	OS.shell_open("https://cysj2-h5.hortorinteractive.com")


func _on_web_castle_pressed() -> void:
	OS.shell_open("https://s.castle.xyz/bhukpMqNRPJU")


func _on_play_pressed() -> void:
	get_tree().change_scene_to_file("res://Tscn/Map/Level/Spring (GeometrySoft).tscn")


func _on_web_tiktok_pressed() -> void:
	OS.shell_open("https://www.tiktok.com/@truongtuandinh.tr")

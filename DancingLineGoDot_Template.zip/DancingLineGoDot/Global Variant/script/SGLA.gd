extends Node

#checkpoint checker
var Checkpoint_crown = 0
var Checkpoint_Area = 0

#CachesGame
var CrownDat = 0
var DiamondDat = 0

#game Selection
var game_current = 0
var Spring_SGeometrysoftS = "res://Tscn/Map/Level/Spring (GeometrySoft).tscn"

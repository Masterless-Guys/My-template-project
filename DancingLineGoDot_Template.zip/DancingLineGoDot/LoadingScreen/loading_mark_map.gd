extends Control

func _ready() -> void:
	$GameEngine/Rolly.play("Roll")
	await get_tree().create_timer(0.245).timeout
	get_tree().change_scene_to_file("res://Lobby/1/Lobby.tscn")
	
	
	




func _on_rolly_animation_finished(anim_name: StringName) -> void:
	
	await get_tree().create_timer(0.1).timeout
	$GameEngine/Rolly.play(anim_name)
	
	

extends RigidBody3D

func colormax(color:Color):
	$mue.get_surface_override_material(0).albedo_color = color
	

func eraseme():
	queue_free()
	

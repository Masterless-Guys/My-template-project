extends Sprite3D

@onready var Animationrootfaded:AnimationPlayer = $PackFaded

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	Animationrootfaded.play("Faded")

var limitedy:int = 5

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if limitedy != 0:
		position.y += 0.2
		limitedy -= 1
		
	
	if modulate.a == 0 :
		queue_free()
		
		
	
